# Warm Up!

## More algorithms/ Interview Questions: 

Pick your warm up from the following


#### Problem 1:

Write a program that automatically converts English text to [Morse code](https://en.wikipedia.org/wiki/Morse_code).

**Bonus**

 Make it convert Morse Code to English too. 

https://morsecode.scphillips.com/morse.html

**note:** Most programmers would probably have trouble writing this in just 45 min to an hour. Focus on the big picture (pseudo-code) and work inward. See how far you can get!

#### Problem 2: 

Write a function that merges two sorted lists into a new sorted list. [1,4,6],[2,3,5] → [1,2,3,4,5,6]. You can do this quicker than concatenating them followed by a sort.

**Do this alone or with a partner, on a whiteboard, or with your computer.**
