# Warm Up

Dig into this open source React App [code](https://github.com/insin/react-hn) and learn what you can learn. 

Discuss with a partner or classmates!

