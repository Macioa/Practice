# Warm ups!

## For today's warm ups, check out the following resources that will help you on your journey as a Node + Express developer!

1. [Node Debugger](https://nodejs.org/api/debugger.html)
2. [Send Emails from Node](http://javascript.tutorialhorizon.com/2015/07/02/send-email-node-js-express/)
3. [JS Linter](https://www.npmjs.com/package/standard) for establishing JS standards for every developer on your team
4. [Send SMS and MMS Notifications with Twilio](https://www.twilio.com/docs/tutorials/server-notifications-node-express)
