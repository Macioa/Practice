# Warm Up

I hope you had a great weekend! Welcome back!

![](https://media.giphy.com/media/2jd7CRuYayGpW/giphy.gif)

#### For today's warm up, please:
1. Get together with a partner for a minimum of 15 minutes to review the Express homework. If possible, work with a partner you haven't worked with yet.
2. Look at eachother's code an ask questions about what you see. 
3. As a pair, submit a few questions to Slack that you had about the homework, or about Node and Express in general
4. After this 15 minute exercise, you may continue discussing in your pair, in the classroom and on Slack. 
5. If there is time remaining, please start looking over the [Mongoose docs](http://mongoosejs.com/)

Today we add a database to our Express Apps and become full stack developers!
