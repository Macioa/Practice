# Warm Up

## Happy Friday!!!!

![](https://media.giphy.com/media/sTczweWUTxLqg/giphy.gif)

For today's warm up, spend some time reviewing a live, in production open source Node + Express App. 

Code [here](https://github.com/DimiMikadze/Mean-Blog/tree/master/server)

## Instructions:

1. Stick with the /server folder. This is where the express app lives!
2. Start with App.js, then check out the Routes and Models folders
3. Make comments about what the code is doing
4. Google things you aren't familliar with! What is passport? What is body-parser? What is morgan?
5. Discuss with your classmates interesting things you find!
