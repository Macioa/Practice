# Sudoku Solver 

## Day 3 - Optimize and Refactor

#### Speed 

How long does it take to work through these puzzles?  Can you make it faster?

You can time your code by using the following code: 

```python
import time

def myCode():
   print "Hi this is my code, its really fast."

t0 = time.time()
myCode()
t1 = time.time()

total_n = t1-t0

print total_n

```

Some things to think about when it comes to speed: 

1. Are you doing any duplicate or unnecessary work? For example are you converting a string to an array only to turn it back into a string again? When maybe you could perform the operations on the string in the first place?
2. Are you doing any nested for loops? That could be OK, but maybe you can stop the loop before it plays all the way out. Or maybe you could avoid the nested loop altogether. 


#### Code Organization and Readability

How does your code hold up in terms of readability and organization? If you came across this code having never worked on it, would you understand it? What can be done to improve this? 

Are your functions limited to ~5 lines?

Are your variables are symantically named?

#### Optional Continuation

There are two more days to this challenge! But tomorrow you have outcomes, and then comes the final stretch of project 4 + Capstone projects. 

If you wish to continue this journey, check out [day 4](https://git.generalassemb.ly/wdi-wc-march2018/warm-ups/blob/master/week-10/thursday.md) and [day 5](https://git.generalassemb.ly/wdi-wc-march2018/warm-ups/blob/master/week-10/friday.md) of this challenge! This challenge has a lot to teach! You will be busy with projects, so you can always come back to this after the course is over. May your errors be few and easy to follow! 


