# Sudoku Solver 

## Day 5

#### Retrospective

[Here](http://norvig.com/sudoku.html) is a solver that can solve ANY valid sudoku puzzle. 

This morning you can take a look at this, and also share with your classmates what you did, and check out their solutions! 

Congratulations! This was a HARD challenge. The idea was not to finish but to work on the _pure problem solving_ aspect of coding by presenting you with a hard problem. 

Give yourselves a pat on the back! 
