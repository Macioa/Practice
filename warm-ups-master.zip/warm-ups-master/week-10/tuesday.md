# Sudoku Solver: Day 2 - Start coding (In Python)

Your Sudoku solver will take a string like this as its input:

```
"619030040270061008000047621486302079000014580031009060005720806320106057160400030"
```

Each consecutive 9 digits represents a row of the Sudoku board, and a `0` represents an empty cell. It'd work like this:

```python
game = SudokuSolver('619030040270061008000047621486302079000014580031009060005720806320106057160400030')
game.solve()

```

Again, **note**, this first iteration might not solve every possible Sudoku board. This means it would finish when it can no longer make a choice and "give up." We'll create the fully-featured version in the next challenge.

Don't worry about the particular format of the board when printed. The key thing is getting the logic around solving/guessing correctly.

#### What about performance?

Do *not* worry about performance yet! Optimizations can come later. Clean, logical code is more important and will be easier to refactor.

#### Testing

Remember, always start with the simplest test case possible. For a Sudoku solver, what's the simplest case? (Besides being passed an already-solved board.) Working with a board that is only missing one number.

```
609238745274561398853947621486352179792614583531879264945723816328196457167485932
```

#### Testing Real Puzzles

[Here](https://git.generalassemb.ly/gist/alexw/725597e4ef9204a48a0d8fd9bd12fe4c) you can find a set of puzzles.

Can your solver solve all the puzzes in both sets?  If not, why not?
