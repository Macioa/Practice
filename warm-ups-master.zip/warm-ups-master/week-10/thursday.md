# Sudoku Solver 

## Day 4: Solving HARD puzzles

## Summary

What happens if a square can contain multiple possible numbers and you don't have enough information to conclude right then and there which number it is?

Most people who play Sudoku "guess," usually by writing possibilities in the corners of the square.


#### Brain Storm and Pseudocode 

Once we've filled in all cells which have only one possible value, we have to guess.  Write out pseudocode for how that might work before you dive in!

#### Code

Write the code to make this happen! 

#### Test 1

Try your new code on the old easy problems. It should still be able to solve them. 

Check out, does it solve the easy one's faster or slower? It's OK either way, but think about _why_. 

#### Test 2 - the HARD ones

Test your new code on [these](https://git.generalassemb.ly/gist/alexw/68aa341882a0978e1e635ad66b057e0f) puzzles. 

Can your solver solve the hardest puzzles?

How long does it take to solve one puzzle?

How long does it take to solve all the puzzles in a set?

