# Sudoku Solver - A non-trivial problem

Over the course of this week you will work **with a partner or group of 3** to build a functional Sudoku puzzle solver the runs in the command line! 
You will accomplish this by going step by step. 

## Summary

[Sudoku](https://en.wikipedia.org/wiki/Sudoku) is a logic-based, combinatorial number-placement puzzle. The objective is to fill a 9×9 grid with digits so that each column, each row, and each of the nine 3×3 sub-grids that compose the grid (also called "boxes") contains all of the digits from 1 to 9.

Whoever creates the puzzle provides a partial solution so that some squares already have numbers. Typically, there are enough initial numbers to guarantee a unique solution.

![Unsolved](https://upload.wikimedia.org/wikipedia/commons/thumb/f/ff/Sudoku-by-L2G-20050714.svg/250px-Sudoku-by-L2G-20050714.svg.png)

![Solved Sudoku](https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Sudoku-by-L2G-20050714_solution.svg/250px-Sudoku-by-L2G-20050714_solution.svg.png)

Puzzles that have one clear solution based on the numbers we start with are "Easy" puzzles. Hard ones require the player to guess, and see what happens, and potentially go back if it doesn't work out. We'll worry about those towards the end of the week. 

Your "board" will come in the form of a string that looks like this: 

`"105802000090076405200400819019007306762083090000061050007600030430020501600308900"`

This reads from left to right and top to bottom. Zeros represent blank spaces. You solver will eventually spit the same string back out but with the zeros replaced by the appropriate number. 


## Today

### Part 0 : Modeling

This morning you won't write any code, just think and strategize, pseudocode and take notes. 

Get together with your partner (or small group; you will work with the same person(s) all week). If one or both of you are not familliar with Sudoku, look it up and play an easy one. Think about what you are doing. What steps am I doing to attempt to solve this?

1. What strategies are you adopting and why?
2. How do you choose where to start?
3. How do you know when to really put a number in a cell?
4. Did you adopt the same notation/board markings while playing Sudoku? Why? If not, why did you choose differently?
5. Are you avoiding any strategies because they're too tedious or require you to remember too much?

The best way to solve it might be to have your code do what you would do to solve it. But then again, it might not be. After all, a computer can afford to try a million things, while a human can't. This challenge can be solved multiple ways. For now just think about these questions. 

Look at the board itself. Think carefully about all the nouns and verbs in a Sudoku game. There's a board, there's columns. What else? 

#### Modeling: Pseudocode for First Iteration

Remember, for the first iteration, we're just going build a solver that fills in "logically necessary" squares and requires no guessing. This might not solve every Sudoku board, although it often solves the easiest. How can you tell when you've filled in all the "logically necessary" squares?

Have each member of the pair/ group write out pseudocode for this version, separately, to the best of their ability, and compare it to each other. How does it differ? Which approach seems more sound? Are there some core operations or methods you need to support?

For example, given a cell/square, you'll probably need at least three methods:

1. Give me the other cells in that cell's row.
2. Give me the other cells in that cell's column.
3. Give me the other cells in that cell's box.

