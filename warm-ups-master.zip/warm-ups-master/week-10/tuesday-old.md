# Warm ups!

## Check out my Reddit Bot! 

Check out [my code](https://gist.github.com/awhit012/089a54b09a53ee389827) for the Reddit bot I made a couple years ago! 

Your assignment is to comment each line (that isn't self-explanatory).

Feel free to ask me questions via Slack!
