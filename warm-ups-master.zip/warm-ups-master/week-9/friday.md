# Discover Communities

There are a lot of communities, forums, email groups etc. in the programming world that could be beneficial to get involved with.

Below are a few that your instruction team has put together for you to check out! 

No need to join all of them all at once and blow up your inbox. You don't need to eat, sleep and drink code. Just check them out and see what resonates with you. 

## Reddit

- [/r/reactjs](https://www.reddit.com/r/reactjs/)

- [/r/javascript](https://www.reddit.com/r/javascript)

- [/r/webdev](https://www.reddit.com/r/webdev/)

- [/r/InternetIsBeautiful](https://www.reddit.com/r/InternetIsBeautiful/)

- [/r/Python](https://www.reddit.com/r/Python/)

- [/r/django](https://www.reddit.com/r/django/)

- [/r/node](https://www.reddit.com/r/node/)

- [/r/programming](https://www.reddit.com/r/programming/)

- [/r/learnprogramming](https://www.reddit.com/r/learnprogramming/)

- [/r/programmerhumor](https://www.reddit.com/r/programmerhumor/)

- [/r/cscareers](https://www.reddit.com/r/cscareers/)

- [/r/cscareerquestions](https://www.reddit.com/r/cscareerquestions/)



## Email lists

- [Hack Design](https://hackdesign.org/), an excellent free course in web design, via email

- [BRUNCH](https://www.rubytapas.com/brunch/), a weekly email with a digestible collection of favorite articles of the week, by programmer and educator, Avdi Grimm

## Other sites

- [Hacker News](https://news.ycombinator.com/)

- [Hash Node](https://hashnode.com/)

- [Free Code Camp](https://www.freecodecamp.org/)

- [Coder Wall](https://coderwall.com/)

- [HackerRank](https://www.hackerrank.com/)




