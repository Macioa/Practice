# Setting up for React Native

Today we are going to take a peek into a very exciting technology, React Native. 

For today's warm up we are going to get you all set up to start coding later this morning. 

First, go [here](https://facebook.github.io/react-native/docs/getting-started.html) and follow the instructions to install `create-react-native-app`, create a new app, and start the server. It will also direct you to install a iPhone or Android app, which will allow you to see your app on your phone! 

You may get an error that looks like this. (I got this error):

```bash
 Unable to start server
See https://git.io/v5vcn for more information, either install watchman or run the following snippet:
  sudo sysctl -w kern.maxfiles=5242880
  sudo sysctl -w kern.maxfilesperproc=524288
        
npm ERR! code ELIFECYCLE
npm ERR! errno 1
npm ERR! AwesomeProject@0.1.0 start: `react-native-scripts start`
npm ERR! Exit status 1
npm ERR! 
npm ERR! Failed at the AwesomeProject@0.1.0 start script.
npm ERR! This is probably not a problem with npm. There is likely additional logging output above.

npm ERR! A complete log of this run can be found in:
npm ERR!     /Users/alexwhite/.npm/_logs/2018-05-06T21_58_48_809Z-debug.log

```

If you do, go ahead and install watchman from your terminal using brew: 

`brew update && brew install watchman` 

Then run again: 

`npm start`

Once you scan the QR code (Awesome right?!) it will take some time for Expo to build. While that's happening take a look at the code created by `create-react-native-app`. 

Note a couple major differences: 

On `App.js` check out what's happening at `StyleSheet.create`

Note the use of `<View>` and `<Text>`! These are not custom components, nor are they HTML! **There is no HTML for native apps!** These are "native components" that get turned into something iOS and Android systems understand. 

## Bonus

If you get through all of that before we start the lesson, go ahead and take a peak further into [the tutorial](https://facebook.github.io/react-native/docs/tutorial.html). We will be using this to learn React Native this morning. But a lot of it is review! Because React Native uses JSX, Props, and State just like ReactJS!

 

