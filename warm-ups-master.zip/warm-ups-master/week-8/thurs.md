# Warm Up!

## Pick your warm up from the following


#### Problem 1:

Write a program that automatically converts English text to Morse code.

**Bonus**

 Make it convert Morse Code to English too. 

https://morsecode.scphillips.com/morse.html

#### Problem 2: 

Write a function that merges two sorted lists into a new sorted list. [1,4,6],[2,3,5] → [1,2,3,4,5,6]. You can do this quicker than concatenating them followed by a sort.

**Do this alone or with a partner, on a whiteboard, or with your computer.**
