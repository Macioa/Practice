# WDI+WC-Mar2018

This morning we have something light: a video! 

This is an amazing live code of Space Invaders coded entirely from scratch using vanilla JS! 

The point of watching this is to excite and inspire you for your project 1, as well as to expose you to some new things. 

We will all watch this together, so a local instructor will play this and screen share from their laptop to the class zoom. 

After you watch, please take the remaining time before the first lesson to discuss what you learned with your classmates. 

https://vimeo.com/105955605
