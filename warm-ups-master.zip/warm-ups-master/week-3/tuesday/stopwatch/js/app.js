$(function() {
	$('#start').on('click', startTimer);
	$('#stop').on('click', stopTimer);
	$('#reset').on('click', resetTimer);
	$('#countdown').on('click', countdownTimer);
}); // end window onload


//===================
// EVENT HANDLERS
// ==================

var startTimer = function() {
	console.log('start timer clicked');
};

var stopTimer = function() {

};

var resetTimer = function() {

};

var countdownTimer = function () {

};
